###################################################
### chunk number 1: preliminaries
###################################################
#line 61 "zoo.Rnw"
library("zoo")
library("tseries")
library("strucchange")
library("fCalendar")
library("fSeries")
online <- FALSE ## if set to FALSE the local copy of MSFT.rda
                ## is used instead of get.hist.quote()
options(prompt = "R> ")


###################################################
### chunk number 2: zoo-prelim
###################################################
#line 210 "zoo.Rnw"
library("zoo")
set.seed(1071)


###################################################
### chunk number 3: zoo-vectors1
###################################################
#line 217 "zoo.Rnw"
z1.index <- ISOdatetime(2004, rep(1:2,5), sample(28,10), 0, 0, 0)
z1.data <- rnorm(10)
z1 <- zoo(z1.data, z1.index)


###################################################
### chunk number 4: zoo-vectors2
###################################################
#line 223 "zoo.Rnw"
z2.index <- as.POSIXct(paste(2004, rep(1:2, 5), sample(1:28, 10), sep = "-"))
z2.data <- sin(2*1:10/pi)
z2 <- zoo(z2.data, z2.index)


###################################################
### chunk number 5: zoo-matrix
###################################################
#line 230 "zoo.Rnw"
Z.index <- as.Date(sample(12450:12500, 10))
Z.data <- matrix(rnorm(30), ncol = 3)
colnames(Z.data) <- c("Aa", "Bb", "Cc")
Z <- zoo(Z.data, Z.index)


###################################################
### chunk number 6: print1
###################################################
#line 254 "zoo.Rnw"
z1
z1[3:7]


###################################################
### chunk number 7: print2
###################################################
#line 259 "zoo.Rnw"
Z
Z[1:3, 2:3]


###################################################
### chunk number 8: subset
###################################################
#line 273 "zoo.Rnw"
z1[ISOdatetime(2004, 1, c(14, 25), 0, 0, 0)]


###################################################
### chunk number 9: summary
###################################################
#line 284 "zoo.Rnw"
summary(z1)
summary(Z)


###################################################
### chunk number 10: zooreg1
###################################################
#line 339 "zoo.Rnw"
zr1 <- zooreg(sin(1:9), start = 2000, frequency = 4)
zr2 <- zoo(sin(1:9), seq(2000, 2002, by = 1/4), 4)
zr1
zr2


###################################################
### chunk number 11: zooreg2
###################################################
#line 352 "zoo.Rnw"
zr1 <- zr1[-c(3, 5)]
zr1
class(zr1)
frequency(zr1)


###################################################
### chunk number 12: zooreg1b
###################################################
#line 365 "zoo.Rnw"
zooreg(1:5, start = as.Date("2005-01-01"))


###################################################
### chunk number 13: zooreg3
###################################################
#line 373 "zoo.Rnw"
is.regular(zr1)
is.regular(zr1, strict = TRUE)


###################################################
### chunk number 14: zooreg4
###################################################
#line 381 "zoo.Rnw"
zr1 <- as.zoo(zr1)
zr1
class(zr1)
is.regular(zr1)
frequency(zr1)


###################################################
### chunk number 15: zooreg5
###################################################
#line 397 "zoo.Rnw"
as.ts(zr1)
identical(zr2, as.zoo(as.ts(zr2)))


###################################################
### chunk number 16: plot1 eval=FALSE
###################################################
## #line 417 "zoo.Rnw"
## plot(Z)


###################################################
### chunk number 17: plot2 eval=FALSE
###################################################
## #line 421 "zoo.Rnw"
## plot(Z, plot.type = "single", col = 2:4)


###################################################
### chunk number 18: plot2-repeat
###################################################
#line 427 "zoo.Rnw"
#line 421 "zoo.Rnw"
plot(Z, plot.type = "single", col = 2:4)
#line 428 "zoo.Rnw"


###################################################
### chunk number 19: plot1-repeat
###################################################
#line 436 "zoo.Rnw"
#line 417 "zoo.Rnw"
plot(Z)
#line 437 "zoo.Rnw"


###################################################
### chunk number 20: plot3
###################################################
#line 439 "zoo.Rnw"
plot(Z, type = "b", lty = 1:3, pch = list(Aa = 1:5, Bb = 2, Cc = 4), col = list(Bb = 2, 4))


###################################################
### chunk number 21: plot3-repeat eval=FALSE
###################################################
## #line 452 "zoo.Rnw"
## #line 439 "zoo.Rnw"
## plot(Z, type = "b", lty = 1:3, pch = list(Aa = 1:5, Bb = 2, Cc = 4), col = list(Bb = 2, 4))
## #line 453 "zoo.Rnw"


###################################################
### chunk number 22: rbind
###################################################
#line 474 "zoo.Rnw"
rbind(z1[5:10], z1[2:3])


###################################################
### chunk number 23: cbind
###################################################
#line 481 "zoo.Rnw"
cbind(z1, z2)


###################################################
### chunk number 24: merge
###################################################
#line 492 "zoo.Rnw"
merge(z1, z2, all = FALSE)


###################################################
### chunk number 25: merge2
###################################################
#line 514 "zoo.Rnw"
merge(z1, pi, 1:10)


###################################################
### chunk number 26: aggregate
###################################################
#line 533 "zoo.Rnw"
firstofmonth <- function(x) as.Date(sub("..$", "01", format(x)))
aggregate(Z, firstofmonth(index(Z)), mean)
aggregate(Z, firstofmonth, head, 1)


###################################################
### chunk number 27: disaggregate
###################################################
#line 546 "zoo.Rnw"
Nile.na <- merge(as.zoo(Nile), zoo(, seq(start(Nile)[1], end(Nile)[1], 1/4)))
head(as.zoo(Nile))
head(na.approx(Nile.na))
head(na.locf(Nile.na))
head(na.spline(Nile.na))


###################################################
### chunk number 28: Ops
###################################################
#line 562 "zoo.Rnw"
z1 + z2
z1 < z2


###################################################
### chunk number 29: cumsum
###################################################
#line 572 "zoo.Rnw"
cumsum(Z)


###################################################
### chunk number 30: coredata
###################################################
#line 595 "zoo.Rnw"
coredata(z1)
coredata(z1) <- 1:10
z1


###################################################
### chunk number 31: index
###################################################
#line 607 "zoo.Rnw"
index(z2)


###################################################
### chunk number 32: index2
###################################################
#line 611 "zoo.Rnw"
index(z2) <- index(z1)
z2


###################################################
### chunk number 33: startend
###################################################
#line 618 "zoo.Rnw"
start(z1)
end(z1)


###################################################
### chunk number 34: window
###################################################
#line 634 "zoo.Rnw"
window(Z, start = as.Date("2004-03-01"))
window(Z, index = index(Z)[5:8], end = as.Date("2004-03-01"))


###################################################
### chunk number 35: window2
###################################################
#line 644 "zoo.Rnw"
window(z1, end = as.POSIXct("2004-02-01")) <- 9:5
z1


###################################################
### chunk number 36: lagdiff
###################################################
#line 659 "zoo.Rnw"
lag(z1, k = -1)
merge(z1, lag(z1, k = 1))
diff(z1)


###################################################
### chunk number 37: coercion
###################################################
#line 680 "zoo.Rnw"
as.data.frame(Z)


###################################################
### chunk number 38: na
###################################################
#line 703 "zoo.Rnw"
z1[sample(1:10, 3)] <- NA
z1
na.omit(z1)
na.contiguous(z1)
na.approx(z1)
na.approx(z1, 1:NROW(z1))
na.locf(z1)


###################################################
### chunk number 39: rollapply
###################################################
#line 744 "zoo.Rnw"
rollapply(Z, 5, sd)
rollapply(Z, 5, sd, na.pad = TRUE, align = "left")


###################################################
### chunk number 40: rollmean
###################################################
#line 756 "zoo.Rnw"
rollmean(z2, 5, na.pad = TRUE)


###################################################
### chunk number 41: strucchange1
###################################################
#line 797 "zoo.Rnw"
library("strucchange")
library("DAAG")
data("fruitohms")
ocus <- gefp(ohms ~ 1, order.by = ~ juice, data = fruitohms)


###################################################
### chunk number 42: strucchange2
###################################################
#line 806 "zoo.Rnw"
plot(ocus)


###################################################
### chunk number 43: tseries1 eval=FALSE
###################################################
## #line 840 "zoo.Rnw"
## library("tseries")
## MSFT <- get.hist.quote(instrument = "MSFT", start = "2001-01-01",
##   end = "2004-09-30", origin = "1970-01-01", retclass = "ts")


###################################################
### chunk number 44: tseries1a
###################################################
#line 846 "zoo.Rnw"
if(online) {
  MSFT <- get.hist.quote("MSFT", start = "2001-01-01",
  end = "2004-09-30", origin = "1970-01-01", retclass = "ts")
  save(MSFT, file = "MSFT.rda", compress = TRUE)
} else {
  load("MSFT.rda")
}


###################################################
### chunk number 45: tseries2
###################################################
#line 863 "zoo.Rnw"
MSFT <- as.zoo(MSFT)
index(MSFT) <- as.Date(index(MSFT))
MSFT <- na.omit(MSFT)


###################################################
### chunk number 46: tseries3
###################################################
#line 875 "zoo.Rnw"
MSFT <- as.zoo(MSFT)


###################################################
### chunk number 47: tseries3
###################################################
#line 881 "zoo.Rnw"
plot(diff(log(MSFT)))


###################################################
### chunk number 48: fCalendar2
###################################################
#line 910 "zoo.Rnw"
library("fCalendar")
z2td <- zoo(coredata(z2), timeDate(index(z2), FinCenter = "GMT"))
z2td


###################################################
### chunk number 49: yearmon1
###################################################
#line 956 "zoo.Rnw"
zr3 <- zooreg(rnorm(9), start = as.yearmon(2000), frequency = 12)
zr3


###################################################
### chunk number 50: yearmon2
###################################################
#line 963 "zoo.Rnw"
aggregate(zr3, as.yearqtr, mean)


###################################################
### chunk number 51: yearmon3
###################################################
#line 970 "zoo.Rnw"
as.Date(index(zr3))
as.Date(index(zr3), frac = 1)


###################################################
### chunk number 52: yearmon4
###################################################
#line 978 "zoo.Rnw"
index(zr3) <- as.POSIXct(index(zr3))
as.irts(zr3)


